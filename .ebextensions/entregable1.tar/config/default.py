class Config(object):
    TESTING  =  False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLALCHEMY_DATABASE_URI_LOCAL = f"sqlite:///development.db"
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:postgres@dbentrega1.c3wryiquwjrg.us-east-2.rds.amazonaws.com:5432/postgres"